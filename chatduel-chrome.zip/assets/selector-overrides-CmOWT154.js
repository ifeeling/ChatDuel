async function o(t){try{const e=await chrome.runtime.sendMessage({type:"selector-config:get",platform:t});return e!=null&&e.ok?e.selectors:void 0}catch{return}}export{o as l};
